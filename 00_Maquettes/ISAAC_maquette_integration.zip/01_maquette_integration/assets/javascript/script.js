let inputs = document.querySelectorAll('.inputs');
let bouttons = document.querySelectorAll('.bouttons');
let submit = bouttons[0];
let validation = document.querySelector('#validation');
let form = document.querySelector('#form');
let email = document.getElementById('email');
let regexEmail = /^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,6}$/;
let small = document.getElementById('small')
let msg = "";




function formVerif(email, msg){
  let emailValue = email.value.trim();     
  
  if (emailValue == "") {
      msg = 'Veuillez renseignez votre mail'
      setError(email, msg);
    }
    else if (!emailValue.match((/^[a-z]+\.[a-z]+@[a-z]+\.[a-z]+$/))) {
      msg = 'votre email n\'est pas valide ';
      /* La fonction `setError` est utilisée pour afficher un message d'erreur à côté d'un champ de saisie
      de formulaire et indiquer visuellement qu'il y a une erreur dans la saisie. Voici ce que fait la
      fonction `setError` dans le code fourni : */
      setError(email, msg)
    }
    else {
      setSucces(email);
    }   
};  


function setSucces(element) {
  let formcontrol = element.parentElement;
  formcontrol.classList.add('succes');

};

function setError(element, infos) {
  let formcontrol = element.parentElement; // je stock le parent de l'élément qui contient l'erreur. (La div avec la classe form-control)
  let small = formcontrol.querySelector('small');
  small.innerText = infos;
  small.classList.remove('hide');
  small.style.color = 'red';
  small.style.fontWeight ='bold'; 
  
};

form.addEventListener('click',(event)=>{
  event.preventDefault();{
    
  };
  formVerif(email,msg);
})