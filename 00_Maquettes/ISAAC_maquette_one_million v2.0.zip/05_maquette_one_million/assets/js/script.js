console.log('connecté !');

const listDiv = document.querySelectorAll('.team');
const listClass = [ 'joanne', 'manuel', 'gaston', 'tracy']
let i = 0;

// boucle tant que :
while (i < listClass.length) {
    let personnes = listDiv[i];
    let classBackGround = listClass[i];
    
    function hovering (element, classe){
    element.classList.toggle(classe);    
    }

    personnes.addEventListener('mouseover',function(){
    hovering(personnes,classBackGround)
    });
    personnes.addEventListener('mouseout',function(){
    hovering(personnes,classBackGround)} 
    )
    i++
};

// // MANUEL
// img2.addEventListener('mouseover', function(){
//     hovering(img2,"manuel");
// });
// img2.addEventListener('mouseout', function(){
//     hovering(img2,"manuel");
   
// });

// //GASTON
// img3.addEventListener('mouseover', function(){
//     hovering(img3,"gaston");   
// });
// img3.addEventListener('mouseout', function(){
//     hovering(img3,"gaston");
    
// });

// // TRACY
// img4.addEventListener('mouseover', function(){
//     hovering(img4,"tracy");
// });
// img4.addEventListener('mouseout', function(){
//     hovering(img4,"tracy")
// });



